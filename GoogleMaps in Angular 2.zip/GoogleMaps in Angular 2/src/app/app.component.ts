import { Component, ViewChild, ElementRef, NgZone, OnInit } from '@angular/core';
import { MouseEvent } from '@agm/core';
import { FormControl, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AgmCoreModule, MapsAPILoader } from '@agm/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'Google Maps in Angular 4.2.4';
  zoom: number = 4;
  
  // initial center position for the map
  lat: number = 20.5937;
  lng: number = 78.9629;
 
   details:string;
  clickedM(label: string, index: number) {
    this.details= label
  }
  
  mapClicked($event: MouseEvent) {
    this.markers.push({
      lat: $event.coords.lat,
      lng: $event.coords.lng,
      draggable: true
    });

    console.log(this.markers);
  }
  
  DragEnd(m: marker, $event: MouseEvent) {
    console.log('dragEnd', m, $event);
  }
  
  markers: marker[] = [
     {
		  lat:20.5937,
		  lng: 78.9629,
		  label: 'India',
		  draggable: true
    },
	   {
		  lat:12.9716,
		  lng: 77.5946,
		  label: 'Bengaluru',
		  draggable: true
    },
        {
		  lat: 18.5204,
		  lng: 73.8567,
		  label: 'Pune',
		  draggable: true
	  }
  ]
}

// just an interface for type safety.
interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}
